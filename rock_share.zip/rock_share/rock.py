"""Step 1: the rock and the oil.

Makes a cylinder of random PoreSpy rock, keeps the pores that connect the bottom face to the top face,
and lets PoreSpy decide the order in which oil fills them (QBIP: widest reachable opening first), up to
breakthrough at the top. The pump rate then turns that order into seconds.

Arrays are [z, y, x]: z is the flow axis and the scanner's rotation axis, oil enters at z = 0.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
from scipy.ndimage import label

from settings import Flow, Rock


@dataclass
class Drainage:
    core: np.ndarray            # bool [z, y, x]: inside the cylinder
    pores: np.ndarray           # bool: pores connected inlet -> outlet (oil can reach them)
    pore_space_all: np.ndarray  # bool: all pores, including the ~2 % that are cut off
    seq: np.ndarray             # int: invasion step at which oil enters each voxel (0 = never)
    state_ids: np.ndarray       # the invasion steps that happen, up to breakthrough
    counts: np.ndarray          # voxels filled by each step
    fill_times_s: np.ndarray    # time after injection start when each step is complete
    seed_used: int              # rock seed + number of rejected tries

    @property
    def porosity(self) -> float:
        return float(self.pores.sum() / self.core.sum())


def cylinder(height: int, diameter: int) -> np.ndarray:
    """True inside a cylinder of the given diameter, stacked height times."""
    c = (diameter - 1) / 2
    y, x = np.meshgrid(np.arange(diameter) - c, np.arange(diameter) - c, indexing="ij")
    disc = (y**2 + x**2) <= (diameter / 2) ** 2
    return np.broadcast_to(disc[None], (height, diameter, diameter)).copy()


def _invade(rock: Rock):
    """The PoreSpy part (slow): random rock, percolation filter, invasion order."""
    import porespy as ps

    core = cylinder(rock.height_vox, rock.diameter_vox)
    shape = [rock.height_vox, rock.diameter_vox, rock.diameter_vox]
    for attempt in range(rock.max_tries):
        pore_space = ps.generators.blobs(shape=shape, porosity=rock.porosity, blobiness=rock.blobiness,
                                         seed=rock.seed + attempt) & core
        clusters, _ = label(pore_space)                                  # number every connected pore cluster
        at_inlet = np.unique(clusters[0][clusters[0] > 0])
        at_outlet = np.unique(clusters[-1][clusters[-1] > 0])
        through = np.intersect1d(at_inlet, at_outlet)                    # clusters touching both faces
        if len(through):
            break
    else:
        raise RuntimeError(f"no percolating rock in {rock.max_tries} tries")
    pores = np.isin(clusters, through)

    inlet = np.zeros_like(pores)
    inlet[0] = pores[0]
    outlet = np.zeros_like(pores)
    outlet[-1] = pores[-1]
    if rock.invasion == "qbip":
        seq = ps.simulations.injection(im=pores, inlets=inlet, outlets=outlet, method="qbip").im_seq
    elif rock.invasion == "ibip":
        seq = ps.simulations.ibip(im=pores, inlets=inlet, maxiter=10 * pores.size).im_seq
    else:
        raise ValueError(f"unknown invasion method {rock.invasion!r}")
    seq = np.where(pores & (np.asarray(seq) > 0), seq, 0).astype(np.int64)
    return core, pores, pore_space, seq, rock.seed + attempt


def run_drainage(rock: Rock, flow: Flow, cache_dir: Path | None = None) -> Drainage:
    key = hashlib.sha1(json.dumps(asdict(rock), sort_keys=True).encode()).hexdigest()[:12]
    cache = Path(cache_dir) / f"rock_{key}.npz" if cache_dir else None
    if cache and cache.exists():
        c = np.load(cache)
        core, pores, pore_space, seq, seed_used = c["core"], c["pores"], c["pore_space"], c["seq"], int(c["seed_used"])
    else:
        core, pores, pore_space, seq, seed_used = _invade(rock)
        if cache:
            cache.parent.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(cache, core=core, pores=pores, pore_space=pore_space, seq=seq, seed_used=seed_used)

    # stop at breakthrough: the first step that reaches the top face
    at_outlet = seq[-1][seq[-1] > 0]
    last = int(at_outlet.min()) if len(at_outlet) else int(seq.max())
    used = seq[(seq > 0) & (seq <= last)]
    state_ids = np.sort(np.unique(used)).astype(np.int64)
    counts = np.bincount(used, minlength=last + 1)[state_ids].astype(np.int64)

    # time model: a step is complete once its whole volume has been pumped in
    fill_times = np.cumsum(counts) * rock.voxel_size_m**3 / flow.pump_rate_m3_s
    return Drainage(core, pores, pore_space, seq, state_ids, counts, fill_times.astype(np.float64), seed_used)
