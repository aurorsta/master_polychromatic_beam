"""The numbers that define the rock and the flow. Change a value here and rerun make_rock.py."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Rock:
    """The synthetic core: a cylinder of random PoreSpy rock."""
    height_vox: int = 160            # along the flow axis = rotation axis (1.6 mm)
    diameter_vox: int = 64           # 0.64 mm
    voxel_size_m: float = 10e-6      # 10 um voxels
    porosity: float = 0.40           # from drainage.ipynb
    blobiness: int = 2               # from drainage.ipynb
    seed: int = 0                    # random rock; the next seed is tried if this one does not percolate
    max_tries: int = 50
    invasion: str = "qbip"           # "qbip" (drainage.ipynb) or "ibip" (the NeCT authors' own phantom)
    air_margin_vox: int = 4          # air around the core in the scanner volume (needed for NeCT's units)

    @property
    def voxel_size_mm(self) -> float:
        return self.voxel_size_m * 1e3


@dataclass(frozen=True)
class Flow:
    """How fast oil is pumped in. Time = injected volume / pump rate."""
    pump_rate_uL_min: float = 0.01/9 * 4578.1/4256.3
    injection_start_s: float = 600.0  # not used by rock.py (time before injection in the CT experiment)

    @property
    def pump_rate_m3_s(self) -> float:
        return self.pump_rate_uL_min * 1e-9 / 60.0
