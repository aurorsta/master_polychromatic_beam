"""Make one random rock and run a drainage through it.

    python make_rock.py              # seed 0
    python make_rock.py --seed 3     # another random rock

Writes rock_seed<N>.npz (all arrays, see rock.py) and rock_seed<N>.png (a slice and the oil saturation over time).
"""
from __future__ import annotations

import argparse
from dataclasses import replace

import matplotlib.pyplot as plt
import numpy as np

from rock import run_drainage
from settings import Flow, Rock

ap = argparse.ArgumentParser()
ap.add_argument("--seed", type=int, default=0)
a = ap.parse_args()

rock, flow = replace(Rock(), seed=a.seed), Flow()
dr = run_drainage(rock, flow)
print(f"seed {dr.seed_used}: porosity {dr.porosity:.3f}, {len(dr.state_ids)} invasion steps, "
      f"breakthrough after {dr.fill_times_s[-1]:.1f} s")

name = f"rock_seed{a.seed}"
np.savez_compressed(f"{name}.npz", core=dr.core, pores=dr.pores, pore_space_all=dr.pore_space_all, seq=dr.seq,
                    state_ids=dr.state_ids, counts=dr.counts, fill_times_s=dr.fill_times_s, seed_used=dr.seed_used)

# fill time of every voxel (NaN = never filled), and oil saturation vs time
step_time = np.full(dr.seq.max() + 1, np.nan)
step_time[dr.state_ids] = dr.fill_times_s
fill_time = np.where(dr.seq > 0, step_time[dr.seq], np.nan)
saturation = np.cumsum(dr.counts) / dr.pores.sum()

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))
x = dr.core.shape[2] // 2
ax1.imshow(np.where(dr.core[:, :, x], ~dr.pores[:, :, x], np.nan), cmap="Greys", vmin=0, vmax=2, origin="lower")
im = ax1.imshow(fill_time[:, :, x], cmap="viridis", origin="lower")
fig.colorbar(im, ax=ax1, label="time oil arrives (s)")
ax1.set(title="middle slice (oil enters at the bottom)", xlabel="y (voxels)", ylabel="z (voxels)")
ax2.plot(dr.fill_times_s, saturation)
ax2.set(title="drainage", xlabel="time after injection start (s)", ylabel="oil saturation")
fig.tight_layout()
fig.savefig(f"{name}.png", dpi=120)
print(f"wrote {name}.npz and {name}.png")
