# Synthetic rock + drainage

Makes a random porous rock (PoreSpy `blobs`) in a cylinder, keeps the pores that connect the bottom to the
top, and lets oil invade from the bottom (PoreSpy QBIP, widest opening first) until it breaks through at the
top. A constant pump rate turns the invasion order into seconds.

This is quasi-static invasion percolation, not a flow simulation: there is no pressure or velocity field.

## Run

    pip install numpy scipy matplotlib porespy
    python make_rock.py --seed 0

Tested with PoreSpy 3.1.1. Takes from a few seconds to a minute.

## Files

- `settings.py`: all the numbers (size, voxel size, porosity, blobiness, pump rate).
- `rock.py`: the rock and the drainage. `run_drainage(Rock(), Flow())` returns a `Drainage` object.
- `make_rock.py`: example that saves the arrays and a figure.

Arrays are `[z, y, x]`, with z the flow direction and oil entering at z = 0. In `seq`, each voxel holds the
invasion step at which oil enters it (0 = never), and `fill_times_s[i]` is when step `state_ids[i]` is complete.
